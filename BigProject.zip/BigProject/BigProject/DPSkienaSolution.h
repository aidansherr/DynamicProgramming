#pragma once
class DPSkienaSolution
{
public:
	DPSkienaSolution();
	~DPSkienaSolution();

	bool isJumble(char * one, char * two, char * three);

};

